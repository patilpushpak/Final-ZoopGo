package com.cognizant.vehiclebar.service;
// Service class for User controller
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognizant.vehiclebar.model.User;
import com.cognizant.vehiclebar.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	UserRepository repository;
	

	/*
	 * Finally add a user to the database after the admin approves it.
	 * Parameter: User object
	 * Return: void
	 */
	public void adduser(User u) {
		
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		u.setPassword(encoder.encode(u.getPassword()));
		u.setIsApproved(false);
		u.setRole("ROLE_USER");
		repository.save(u);
	}
	

	/*
	 * Add a pending user with ROLE_USER
	 * Parameter: USER object
	 * Return: boolean
	 */
	public boolean addadmin(User u)
	{
		Optional<User> user = repository.findUserByUsername(u.getUsername());
		Optional<User> user1 = repository.findUserByContactNumber(u.getContactNumber());
		if(user!=null || user1!=null)
		{
			return false;
		}
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		u.setPassword(encoder.encode(u.getPassword()));
		u.setRole("ROLE_ADMIN");
		repository.save(u);
		return true;
	}
	

	/*
	 * Get all the user list who are not approved
	 * Parameter:Void
	 * Return: List<User>
	 */
	public List<User> getPendingUserList()
	{
		return repository.findPendingUsers();
	}
	

	/*
	 * Approve a particular user
	 * Parameter: Long ID
	 * Return: void
	 */
	public void approveUser(long id){
		repository.approveUSer(id);
	}
	
	
	public Optional<User> getUserByName(String email){
		Optional<User> user = repository.findUserByUsername(email);
		return user;
	}

	public void rejectUser(long id){
		repository.deleteById(id);
	}
	
	public String getPhoneNumber(String username){
		return repository.getContactNumber(username);	
	}
	
}
