import { Component, OnInit } from '@angular/core';
import { AuthCredentialService } from '../../service/auth-credential.service';
import { MessageServiceService } from '../../service/message-service.service';

@Component({
  selector: 'app-user-notification',
  templateUrl: './user-notification.component.html',
  styleUrls: ['./user-notification.component.css']
})
export class UserNotificationComponent implements OnInit {
username
msg
  constructor(private auth:AuthCredentialService,private msgService:MessageServiceService) { }

  ngOnInit() {
    this.username=this.auth.getSessionUsername()
    this.getDisplay()
  }

  // Get the updated notification of the user
  getDisplay()
  {
    this.msgService.getUserNotification(this.username).subscribe(data =>
      {
        this.msg=data
      }) 
  }

  // Delete the user notification
  onOK(notification)
  {
    this.msgService.delUserNotification(this.auth.getSessionUsername(),notification).subscribe(data =>
      {
        this.getDisplay()
      })
  }

}
