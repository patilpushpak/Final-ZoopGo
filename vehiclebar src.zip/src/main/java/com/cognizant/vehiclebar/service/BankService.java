package com.cognizant.vehiclebar.service;
// Service class for bank controller
// Written by Souvik
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Service;

import com.cognizant.vehiclebar.model.BankCard;
@Service
public class BankService {
	private static List<BankCard> addedCard = new ArrayList<BankCard>();
	
	// List of cards added to the bank	
	static
	{
		addedCard.add(new BankCard("souvik","4444-5555-6666-7777","October",2025,344));
		addedCard.add(new BankCard("dummy","5555-6666-7777-8888","November",2039,355));
	}
	
	/*
	 * Method for validating the payment card and return a random generated OTP
	 * Parameter: BankCard Object
	 * Return: INTEGER i.e., OTP
	 */
	public int aunthenticate(BankCard b)
	{
		Random rand = new Random();
		for(BankCard bo:addedCard)
		{
			if((bo.getCardNumber().equals(b.getCardNumber())) || bo.getCVV() == b.getCVV())
			{
				return rand.nextInt(10000);
			}
		}
		return 000;
	}
	
	
}
