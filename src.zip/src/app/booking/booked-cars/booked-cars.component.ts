import { Component, OnInit } from '@angular/core';
import { BookingServiceService } from 'src/app/service/booking-service.service';
import { AuthCredentialService } from 'src/app/service/auth-credential.service';
import { Router } from '@angular/router';
// Display the list of booked vehicles for a particular login
@Component({
  selector: 'app-booked-cars',
  templateUrl: './booked-cars.component.html',
  styleUrls: ['./booked-cars.component.css']
})
export class BookedCarsComponent implements OnInit {
vehicles
username
  constructor(private bookedService:BookingServiceService,private auth:AuthCredentialService,private router:Router) { }

  ngOnInit() {
    this.username= this.auth.getSessionUsername()
    this.bookedService.getCart(this.username).subscribe(data =>
      {
        this.vehicles = data
      })
  }

  // Route to the booking details component
  onDisplay(id)
  {
    this.router.navigate(['bookingDetails',id])
  }

}
