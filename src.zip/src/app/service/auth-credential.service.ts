import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {map} from 'rxjs/operators';
import { logging } from 'protractor';
import { MessageServiceService } from './message-service.service';

@Injectable({
  providedIn: 'root'
})
export class AuthCredentialService {

  constructor(private http:HttpClient) { }

  // Handling the authentication with the backend and recieving the token and setting the session storage
    handleAuthorization(username,password) 
    {
      
     return this.http.post<any>(`http://localhost:8090/authenticate`,{username,password}).pipe(
        map(
          data =>
          {
            sessionStorage.setItem('role',data.role)
            sessionStorage.setItem('user',username)
            sessionStorage.setItem('token',`Bearer ${data.token}`)
            return data
          }
        )
      )
    }


 

// Get the username stored in session
    getSessionUsername()
    {
      return sessionStorage.getItem('user')
    }

    // Get the JWT token for a logged in user
    getSessionToken()
    {
      return sessionStorage.getItem('token')
    }

    // Check whether user is admin or not
    isAdmin()
    {
      
      return (sessionStorage.getItem('role') === '[ROLE_ADMIN]')
    }

    // check whether user logged has role of ROLE_USER or not
    isUser()
    {
      return (sessionStorage.getItem('role') === '[ROLE_USER]')
    }

    // Check whether user is logged in or not
    isLoggedIn()
    {
      return !(sessionStorage.getItem('user') === null)
    }

    // check whether user is logged out or not
    isloggedout()
    {
      return (sessionStorage.getItem('user') === null)
    }

    // Finally clear all the sessionStorage data
     logout()
      {
        sessionStorage.removeItem('role')
        sessionStorage.removeItem('user')
        sessionStorage.removeItem('token')
      }

}
