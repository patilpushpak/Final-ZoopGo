export interface Vehicles {
	 id: number;
	  name: string;
	  vehicleNumber: string;
	  branch: string;
	  vehicleType: string;
	  insuranceExpiryDate: Date;
	  lastServiceDate: Date;
	  serviceDueDate: Date;
	  isActive: boolean;
	  image: string;
	  price : number
}