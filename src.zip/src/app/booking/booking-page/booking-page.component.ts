import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthCredentialService } from 'src/app/service/auth-credential.service';
import { BookingServiceService } from 'src/app/service/booking-service.service';
import { MessageServiceService } from 'src/app/service/message-service.service';
import { PaymentServiceService } from 'src/app/service/payment-service.service';
// Get all the booking details from the user like start date and end date
@Component({
  selector: 'app-booking-page',
  templateUrl: './booking-page.component.html',
  styleUrls: ['./booking-page.component.css']
})
export class BookingPageComponent implements OnInit {
id
price 
cart:MyVehicle
  constructor(private route:ActivatedRoute,private auth:AuthCredentialService,private bookService:BookingServiceService,private router:Router,private msgService:MessageServiceService,private payService:PaymentServiceService) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id']
    this.price = this.bookService.getPrice()
    console.log(this.price)
  }

  // Submit the entered data and calculate the number of days and price and route to paymentInfo component
  onSubmit(data)
  {
  let startDate = new Date(data.startDate)
  let endDate = new Date(data.endDate)
    let difference = endDate.getTime() - startDate.getTime();
    let daysBetween = (difference / (1000*60*60*24));
    let cost = (this.price * daysBetween)
    this.cart = {vehicleId:this.id,username:this.auth.getSessionUsername(),startDate:data.startDate,endDate:data.endDate,totalCost : cost, days : daysBetween}
    this.msgService.setVehicleID(this.id)
    // this.bookService.storetoCart(this.cart)
    // this.router.navigate(['payment',this])

    //  this.bookService.addToCart(this.cart).subscribe(data =>
    //     {
    //       //this.router.navigate(['listVehicle'])
    //      this.router.navigate(['paymentinfo',this.id])
    //   })
    this.payService.setCart(this.cart)
    this.router.navigate(['paymentinfo',this.id])
  
  }

}

// Interface for Vehicle
export interface MyVehicle
{
  vehicleId:number
  username:String,
  startDate:Date,
  endDate:Date,
  totalCost : number,
  days : number

  
}