package com.cognizant.vehiclebar.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.vehiclebar.model.User;
import com.cognizant.vehiclebar.service.UserService;



@CrossOrigin
@RestController
public class UserController {

	@Autowired
	private UserService userService ;
	
	//For handling user registration request
	@PostMapping(path="/adduser")
	public void addUser(@RequestBody User u)
	{
		userService.adduser(u);	
	}
	
	// For handling admin registration request
	@PostMapping(path="/addadmin")
	public boolean addAdmin(@RequestBody User u)
	{
		return userService.addadmin(u);
	}
	
	// or getting all pending users for admin to approve or reject
	@GetMapping(path="/pendingUser")
	public List<User> getPendingUsers()
	{
		return userService.getPendingUserList();
	}
	
	// Get a particular user information based on username
	@GetMapping(path="/userInfo/{username}")
	public Optional<User> getUserInfo(@PathVariable String username)
	{
		return userService.getUserByName(username);
	}
	
	// Approve a particular user 
	@PostMapping(path="/userApprove")
	public void addusers(@RequestBody User u)
	{
		 userService.approveUser(u.getId());
	}
	
	// Reject a particular user
	@PostMapping(path="/userReject")
	public void rejectusers(@RequestBody User u)
	{
		userService.rejectUser(u.getId());;
	}
	
	// Get the phone number of a particular user for notification related purposes
	@GetMapping(path="/userPhone/{username}")
	public String getPhoneNumber(@PathVariable String username)
	{
		return userService.getPhoneNumber(username);
	}
	
}
