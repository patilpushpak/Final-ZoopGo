import { Component, OnInit } from '@angular/core';
import { RegServiceService } from 'src/app/service/reg-service.service';
import { Router } from '@angular/router';
// Registers the users 
@Component({
  selector: 'app-user-reg',
  templateUrl: './user-reg.component.html',
  styleUrls: ['./user-reg.component.css']
})
export class UserRegComponent implements OnInit {
  user:User
  constructor(private usrService:RegServiceService,private router:Router) { }

  ngOnInit() {

  }
  // Send the user entered details to backend and route to the Registration Success Page
  onSubmit(data)
  {
  
     this.user = { firstName:data.firstName,lastName:data.lastName,age:data.age,gender:data.gender,contactNumber:data.contactNumber,username:data.username,password:data.password}
     console.log(this.user)
     this.usrService.addUser(this.user).subscribe(data =>
       {
         this.router.navigate(['regSuccess'])
       })
  }


}


export interface User
{
  firstName:string
  lastName:string
  age:number
  gender:string
  contactNumber:number
  username:string
  password:string
}
