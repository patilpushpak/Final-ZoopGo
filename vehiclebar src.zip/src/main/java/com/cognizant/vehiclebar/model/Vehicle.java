package com.cognizant.vehiclebar.model;
// Model class for Vehicle
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vehicle")
public class Vehicle {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private long id;
	@Column(name="vehicle_name")
	private String name;
	@Column(name="vehicle_no")
	private String vehicleNumber;
	@Column(name="branch")
	private String branch;
	@Column(name="vehicle_type")
	private String vehicleType;
	@Column(name="ins_exp_date")
	private Date insuranceExpiryDate;
	@Column(name="last_serviced_date")
	private Date lastServiceDate;
	@Column(name="service_due_date")
	private Date serviceDueDate;
	@Column(name="is_active")
	private boolean isActive;
	@Column(name="price")
	private double price;
	@Column(name="vehicle_image")
	private String image;
	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Vehicle(long id, String name, String vehicleNumber, String branch, String vehicleType,
			Date insuranceExpiryDate, Date lastServiceDate, Date serviceDueDate, boolean isActive, double price, String image) {
		super();
		this.id = id;
		this.name = name;
		this.vehicleNumber = vehicleNumber;
		this.branch = branch;
		this.vehicleType = vehicleType;
		this.insuranceExpiryDate = insuranceExpiryDate;
		this.lastServiceDate = lastServiceDate;
		this.serviceDueDate = serviceDueDate;
		this.isActive = isActive;
		this.price = price;
		this.image = image;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getVehicleNumber() {
		return vehicleNumber;
	}
	public void setVehicleNumber(String vehicleNumber) {
		this.vehicleNumber = vehicleNumber;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	public Date getInsuranceExpiryDate() {
		return insuranceExpiryDate;
	}
	public void setInsuranceExpiryDate(Date insuranceExpiryDate) {
		this.insuranceExpiryDate = insuranceExpiryDate;
	}
	public Date getLastServiceDate() {
		return lastServiceDate;
	}
	public void setLastServiceDate(Date lastServiceDate) {
		this.lastServiceDate = lastServiceDate;
	}
	public Date getServiceDueDate() {
		return serviceDueDate;
	}
	public void setServiceDueDate(Date serviceDueDate) {
		this.serviceDueDate = serviceDueDate;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((branch == null) ? 0 : branch.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((insuranceExpiryDate == null) ? 0 : insuranceExpiryDate.hashCode());
		result = prime * result + (isActive ? 1231 : 1237);
		result = prime * result + ((lastServiceDate == null) ? 0 : lastServiceDate.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((serviceDueDate == null) ? 0 : serviceDueDate.hashCode());
		result = prime * result + ((vehicleNumber == null) ? 0 : vehicleNumber.hashCode());
		result = prime * result + ((vehicleType == null) ? 0 : vehicleType.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vehicle other = (Vehicle) obj;
		if (branch == null) {
			if (other.branch != null)
				return false;
		} else if (!branch.equals(other.branch))
			return false;
		if (id != other.id)
			return false;
		if (insuranceExpiryDate == null) {
			if (other.insuranceExpiryDate != null)
				return false;
		} else if (!insuranceExpiryDate.equals(other.insuranceExpiryDate))
			return false;
		if (isActive != other.isActive)
			return false;
		if (lastServiceDate == null) {
			if (other.lastServiceDate != null)
				return false;
		} else if (!lastServiceDate.equals(other.lastServiceDate))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (serviceDueDate == null) {
			if (other.serviceDueDate != null)
				return false;
		} else if (!serviceDueDate.equals(other.serviceDueDate))
			return false;
		if (vehicleNumber == null) {
			if (other.vehicleNumber != null)
				return false;
		} else if (!vehicleNumber.equals(other.vehicleNumber))
			return false;
		if (vehicleType == null) {
			if (other.vehicleType != null)
				return false;
		} else if (!vehicleType.equals(other.vehicleType))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Vehicle [id=" + id + ", name=" + name + ", vehicleNumber=" + vehicleNumber + ", branch=" + branch
				+ ", vehicleType=" + vehicleType + ", insuranceExpiryDate=" + insuranceExpiryDate + ", lastServiceDate="
				+ lastServiceDate + ", serviceDueDate=" + serviceDueDate + ", isActive=" + isActive + ", price=" + price
				+ "]";
	}
	
	
	
}
