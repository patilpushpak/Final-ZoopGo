import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminListVehicleComponent } from './admin-list-vehicle.component';

describe('AdminListVehicleComponent', () => {
  let component: AdminListVehicleComponent;
  let fixture: ComponentFixture<AdminListVehicleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminListVehicleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminListVehicleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
