package com.cognizant.vehiclebar.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.vehiclebar.model.Vehicle;
import com.cognizant.vehiclebar.service.VehicleService;



@CrossOrigin
@RestController
public class VehicleController {

	@Autowired
	private VehicleService vehicleService;

	@GetMapping(path="listVehicle")
	public List<Vehicle> getVehicle()
	{
		return vehicleService.getVehicleListUser();
	}
	
	@GetMapping(path="AdminlistVehicle")
	public List<Vehicle> getAdminVehicle()
	{
		return vehicleService.getVehicleListAdmin();
	}
	
	
	@GetMapping(path="/vehicle/{id}")
	public Optional<Vehicle> getVehicleById(@PathVariable long id)
	{
		Optional<Vehicle> v = vehicleService.getVehiclebyId(id);
		return v;
	}
	
	@PostMapping(path="/vehicle")
	public boolean addvehicle(@RequestBody Vehicle v)
	{
		return vehicleService.addVehicle(v);
	}
	
	@PutMapping(path="/vehicle/{id}")
	public void Update(@RequestBody Vehicle v,@PathVariable int id)
	{
		vehicleService.update(v, id);
	}
	
	@DeleteMapping(path="/vehicle/{id}")
	public void deleteVehicle(@PathVariable long id)
	{
		vehicleService.deleteVehicle(id);
	}
}	
