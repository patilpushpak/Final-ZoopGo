import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ListVehicleService } from '../service/list-vehicle.service';
import { AuthCredentialService } from '../service/auth-credential.service';
// Display the landing page for guest 
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  vehicles
  searchVehicleList

  filter: string[] = ['All', 'Sedan', 'SUV', 'Coupe', 'Hatchback']

  constructor(private router:Router,private vehicleService:ListVehicleService,private auth:AuthCredentialService) { }

  ngOnInit() {
    this.vehicleService.getListVehicle().subscribe(res =>
      {
        this.vehicles = res;
        this.searchVehicleList = this.vehicles;

      });
  }

  // Reserve functionality if user is logged in else route to user login page
  onDisplay()
  {
    if(this.auth.isloggedout())
    {
      this.router.navigate(['userLogin'])
    }
    else
    {
      console.log('start booking')
    }
  }

  // Search a particular vehicle
  onSearch(value: string){
    this.searchVehicleList = this.vehicles.filter((vehicle) => vehicle.name.toLowerCase().includes(value.toLowerCase()));
    console.log(this.searchVehicleList)
    this.vehicleService.getSubject().next(this.searchVehicleList);
  
  }

  // Read the input from the search bar
  onInput(value:string){
    this.searchVehicleList = this.vehicles.filter((vehicle) => vehicle.name.toLowerCase().includes(value.toLowerCase()));
    console.log(this.searchVehicleList)
    this.vehicleService.getSubject().next(this.searchVehicleList);
    
  }

// Filter the search based in ceratin fields
  onFilter(value){
    if(value != "All"){
      this.searchVehicleList = this.vehicles.filter((vehicle) => vehicle.vehicleType.toLowerCase().includes(value.toLowerCase()));
      this.vehicleService.getSubject().next(this.searchVehicleList);
    }else{
      this.searchVehicleList = this.vehicles;
      this.vehicleService.getSubject().next(this.searchVehicleList)
    }
  }


 }
