import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { UserOptionsComponent } from './user/user-options/user-options.component';
import { AdminOptionsComponent } from './admin/admin-options/admin-options.component';
import { UserLoginComponent } from './user/user-login/user-login.component';
import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { UserRegComponent } from './user/user-reg/user-reg.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { WelcomeComponent } from './welcome/welcome.component';
import { HttpInterceptorService } from './service/http-interceptor.service';
import { ListVehicleComponent } from './Vehicle/list-vehicle/list-vehicle.component';
import { RegSuccessComponent } from './reg-success/reg-success.component';
import { LogoutComponent } from './logout/logout.component';
import { AdminMessagesComponent } from './admin/admin-messages/admin-messages.component';
import { AdminRegComponent } from './admin/admin-reg/admin-reg.component';
import { UserDetailsComponent } from './user/user-details/user-details.component';
import { AdminListVehicleComponent } from './admin/admin-list-vehicle/admin-list-vehicle.component';
import { AdminEditVehicleComponent } from './admin/admin-edit-vehicle/admin-edit-vehicle.component';

import { UserNotificationComponent } from './user/user-notification/user-notification.component';
import { VehicleDetailsComponent } from './Vehicle/vehicle-details/vehicle-details.component';
import { AdminAddComponent } from './admin/admin-add/admin-add.component';
import { BookingPageComponent } from './booking/booking-page/booking-page.component';
import { BookedCarsComponent } from './booking/booked-cars/booked-cars.component';
import { BookingDetailsComponent } from './booking/booking-details/booking-details.component';
import { SmsService } from './service/sms.service';
import { PaymentInfoComponent } from './payment/payment-info/payment-info.component';
import { PaymentCheckoutComponent } from './payment/payment-checkout/payment-checkout.component';
import { PaymentOTPComponent } from './payment/payment-otp/payment-otp.component';
import { PaymentSuccessComponent } from './payment/payment-success/payment-success.component';
import { PaymentRejectComponent } from './payment/payment-reject/payment-reject.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    UserOptionsComponent,
    AdminOptionsComponent,
    UserLoginComponent,
    AdminLoginComponent,
    UserRegComponent,
    WelcomeComponent,
    ListVehicleComponent,
    RegSuccessComponent,
    LogoutComponent,
    AdminMessagesComponent,
    AdminRegComponent,
    UserDetailsComponent,
    AdminListVehicleComponent,
    AdminEditVehicleComponent,
    AdminAddComponent,
    UserNotificationComponent,
    VehicleDetailsComponent,
    BookingPageComponent,
    BookedCarsComponent,
    BookingDetailsComponent,
    PaymentInfoComponent,
    PaymentCheckoutComponent,
    PaymentOTPComponent,
    PaymentSuccessComponent,
    PaymentRejectComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [{
    provide:HTTP_INTERCEPTORS,useClass:HttpInterceptorService,multi:true
  }, SmsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
