package com.cognizant.vehiclebar.controller;
// Controller for all cart related operation
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.vehiclebar.model.Cart;
import com.cognizant.vehiclebar.model.Vehicle;
import com.cognizant.vehiclebar.service.CartService;
import com.cognizant.vehiclebar.service.UserService;

@CrossOrigin
@RestController
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	UserService userService;
	
	// Add the booked cars to the Cart
	@PostMapping(path="/addToCart")
	public void addToCart(@RequestBody Cart c)
	{
		cartService.addTocart(c);
	}
	
	// Get all booked cars of a user
	@GetMapping(path="/getCart/{username}")
	public List<Vehicle> getCart(@PathVariable String username)
	{
		return cartService.getAllCartCars(username);
	}
	
	// Get a particular Cart based on vehicle id and user id
	@GetMapping(path="/getCartDetails/{username}/{vehicleID}")
	public Cart getCartDetails(@PathVariable String username,@PathVariable int vehicleID)
	{
		return cartService.getCartInfo(username, vehicleID);
	}
	
	// Delete a appropriate cart item based on vehicleID and username
	@DeleteMapping(path="/cart/{vehicleId}/{username}")
	public void removeCart(@PathVariable long vehicleId,@PathVariable String username)
	{
		cartService.removeFromCart(username ,vehicleId);
	}
}
