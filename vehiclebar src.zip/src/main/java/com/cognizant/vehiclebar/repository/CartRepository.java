package com.cognizant.vehiclebar.repository;

// All cart related queries and function
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.vehiclebar.model.Cart;

public interface CartRepository extends JpaRepository<Cart, Long> {

	// Query for getting the cart details
	@Query(value = "SELECT * FROM cart WHERE user_name = ? AND vehicle_id = ? LIMIT 1;", nativeQuery = true)
	Cart getCartInfo(String username, long vehicleId);
	
	
	// Query for deleting a particular cart entry
	@Modifying
	@Transactional
	@Query(value = "DELETE from cart WHERE user_name = ? AND vehicle_id = ?;", nativeQuery = true)
	void deleteCartItem(String username, long vehicleId);
	
}
