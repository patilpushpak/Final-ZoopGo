import { TestBed } from '@angular/core/testing';

import { AuthCredentialService } from './auth-credential.service';

describe('AuthCredentialService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AuthCredentialService = TestBed.get(AuthCredentialService);
    expect(service).toBeTruthy();
  });
});
