package com.cognizant.vehiclebar.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.vehiclebar.model.BankCard;
import com.cognizant.vehiclebar.service.BankService;

//Controller for authenticating the payment card

@CrossOrigin
@RestController
public class BankController {

	@Autowired
	private BankService bankService;
	
	@PostMapping(path="/authenticateCard")
	public int getOTP(@RequestBody BankCard b)
	{
		return bankService.aunthenticate(b);
	}
}
