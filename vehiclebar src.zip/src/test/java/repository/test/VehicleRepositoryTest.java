package repository.test;


import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;


import com.cognizant.vehiclebar.ZoopGoApplication;
import com.cognizant.vehiclebar.model.Vehicle;
import com.cognizant.vehiclebar.repository.VehicleRepository;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = ZoopGoApplication.class)
@SpringBootTest
public class VehicleRepositoryTest {
	
	@Autowired
	VehicleRepository vehicleRepository;

	@Test
	public void getVehicleListCustomer() {
		assert(vehicleRepository.getVehicleListCustomer().size() == 2);
	}
	
	@Test
	public void getVehicleById(){
		assert(vehicleRepository.getVehicleById(1).get().getName().equals("WagonR"));
	}

	@Test
	public void getVehicleByVehicleNumber(){
		assert(vehicleRepository.getVehicleByVehicleNumber("MH12C9365").get().getName().equals("WagonR"));
	}
	
	@Test
	public void deleteVehicle(){
		vehicleRepository.deleteVehicleById(4L);
		assert(vehicleRepository.getVehicleById(4L) == null);
	}
	
	@Test
	public void addVehicle(){
		Vehicle vehicle = new Vehicle(25,"Jeep Compass","MH12C7198","Hinjewadi","SUV",new Date(),new Date(),new Date(),true, 600, "https://stimg.cardekho.com/images/carexteriorimages/930x620/Jeep/Jeep-Compass/5937/1559651334039/front-left-side-47.jpg");
		vehicleRepository.save(vehicle);
		assert(vehicleRepository.getVehicleById(25L).get().getName().equals("Jeep Compass"));
	}
}
