package com.cognizant.vehiclebar.service;
// Service class for Vehicle controller
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.vehiclebar.model.Vehicle;
import com.cognizant.vehiclebar.repository.VehicleRepository;

@Service
public class VehicleService {
	
	@Autowired
	VehicleRepository vehicleRepository;
	
	/*
	 * Get all the vehicle for Admin
	 * Parameter: void
	 * Return: LIst<Vehicle>
	 */
	public List<Vehicle> getVehicleListAdmin()
	{
		return vehicleRepository.findAll();
	}
	
	
	/*
	 * Get all the vehicle for User
	 * Parameter: void
	 * Return: List<Vehicle>
	 */
	public List<Vehicle> getVehicleListUser()
	{
		return vehicleRepository.getVehicleListCustomer();
	}
	
	
	/*
	 * Add a particular vehicle to the database
	 * Parameter: Vehicle Object
	 * Return: boolean
	 */
	public boolean addVehicle(Vehicle vehicle) 
	{
		vehicleRepository.save(vehicle);
		return true;
	}
	
	
	/*
	 * Update a particular vehicle based on id
	 * Parameter: Vehicle Object, integer id
	 * Return: void
	 */
	public void update(Vehicle vehicle, int id)
	{
		vehicle.setId(id);
		vehicleRepository.save(vehicle);		
	}
	
	
	
	/*
	 * Delete a particular vehicle based on vehicle ID
	 * Parameter: Long ID
	 * Return: void
	 */
	public void deleteVehicle(long id)
	{
		vehicleRepository.deleteVehicleById(id);
	}
	
	
	/*
	 * Get a particular vehicle based on id
	 * Parameter: Long ID
	 * Return: Optional<Vehicle>
	 */
	public Optional<Vehicle> getVehiclebyId(long id)
	{
		return vehicleRepository.getVehicleById(id);
	}
	
}
