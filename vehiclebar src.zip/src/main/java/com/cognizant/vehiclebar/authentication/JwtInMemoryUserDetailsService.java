package com.cognizant.vehiclebar.authentication;
// This is basically used for loading the users from the database and returning the user to JwtAuthenticationRestController

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cognizant.vehiclebar.model.User;
import com.cognizant.vehiclebar.repository.UserRepository;

@Service
public class JwtInMemoryUserDetailsService implements UserDetailsService {
	
	@Autowired
	private UserRepository userRepository;
	
	private JwtUserDetails jwtUserDetails;
	private User user;

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	  user = userRepository.findUserByUsername(username).get();

    if (user == null) {
      throw new UsernameNotFoundException(String.format("USER_NOT_FOUND '%s'.", username));
    }
    else
    {
    	jwtUserDetails = new JwtUserDetails(user);
    }

    return jwtUserDetails;
  }

}


