import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthCredentialService } from 'src/app/service/auth-credential.service';
import { BookingServiceService } from 'src/app/service/booking-service.service';
import { PaymentServiceService } from 'src/app/service/payment-service.service';
// Display the details of particular booked vehicles
@Component({
  selector: 'app-booking-details',
  templateUrl: './booking-details.component.html',
  styleUrls: ['./booking-details.component.css']
})
export class BookingDetailsComponent implements OnInit {
vehicleId
cart
username
  constructor(private route:ActivatedRoute,private auth:AuthCredentialService,private cartService:BookingServiceService,private payService:PaymentServiceService,private router:Router) { }

  ngOnInit() {
    this.username= this.auth.getSessionUsername()
    this.vehicleId = this.route.snapshot.params['id']
    this.cartService.getCartService(this.username,this.vehicleId).subscribe(data =>
      {
        this.cart=data
      })
    
  }

  // For cancelling the booking of vehicles for a particular user
  onCancel(id,username)
  {
    this.payService.paymentDeclined(id,username).subscribe(data =>
      {
        this.router.navigate(['bookedCars'])
      })
  }

}
