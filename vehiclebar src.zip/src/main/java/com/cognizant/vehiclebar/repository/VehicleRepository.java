package com.cognizant.vehiclebar.repository;
// Query related to vehicle operation and function
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.vehiclebar.model.Vehicle;

public interface VehicleRepository extends JpaRepository<Vehicle, Integer> {
	
	// Get the cart field depending on username
	@Query(value = "SELECT v.id, v.vehicle_name, v.vehicle_no, v.branch, v.vehicle_type, v.ins_exp_date,"
			+ " v.last_serviced_date, v.service_due_date, v.is_active, v.price, v.vehicle_image FROM vehicle v ,"
			+ "cart c WHERE c.user_name = ? AND v.id = c.vehicle_id;", nativeQuery = true)
	List<Vehicle> getCartByUserName(String username);

	// Get the list of vehicle which are active 
	@Query(value = "SELECT * FROM vehicle where is_active = 1", nativeQuery = true)
	List<Vehicle> getVehicleListCustomer();

	
	// Get the vehicle based on ID 
	@Query(value = "select * from vehicle where id = ?", nativeQuery=true)
	Optional<Vehicle> getVehicleById(long id);
	
	// Get the Vehicle based on vehicle number 
	@Query(value = "select * from vehicle where vehicle_no = ?", nativeQuery=true)
	Optional<Vehicle> getVehicleByVehicleNumber(String vehicle_no);
	
	// Delete a particular vehicle based on vehicle ID.
	@Modifying
	@Transactional
	@Query(value = "delete from vehicle where id = ?", nativeQuery=true)
	void deleteVehicleById(long id);
}
