import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthCredentialService } from 'src/app/service/auth-credential.service';
import { BookingServiceService } from 'src/app/service/booking-service.service';
import { PaymentServiceService } from 'src/app/service/payment-service.service';
// Cart Details page for a particular booking
@Component({
  selector: 'app-payment-info',
  templateUrl: './payment-info.component.html',
  styleUrls: ['./payment-info.component.css']
})
export class PaymentInfoComponent implements OnInit {
id  
username
cart
  constructor(private route:ActivatedRoute,private auth:AuthCredentialService,private bookService:BookingServiceService,private router:Router,private payService:PaymentServiceService) { }

  ngOnInit() {
    this.id= this.route.snapshot.params['id']
    this.username = this.auth.getSessionUsername()
    this.cart=this.payService.getCart()
 

  }
// Route to payment gateway
  onPay(data)
  {
    this.router.navigate(['checkout',data])
  }

}
