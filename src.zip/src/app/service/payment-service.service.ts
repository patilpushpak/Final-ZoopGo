import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: "root"
})
export class PaymentServiceService {
  cart;
  constructor(private http: HttpClient) {}
  //Authentoicate the card detail
  paymentAuthenticate(card) {
    return this.http.post(`http://localhost:8090/authenticateCard`, card);
  }
  //Decline the transaction
  paymentDeclined(id, username) {
    return this.http.delete(`http://localhost:8090/cart/${id}/${username}`);
  }
  //Set cart
  setCart(cart) {
    this.cart = cart;
  }
  //Return cart
  getCart() {
    return this.cart;
  }
}
