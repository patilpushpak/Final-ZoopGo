import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// Transaction Declined Component
@Component({
  selector: 'app-payment-reject',
  templateUrl: './payment-reject.component.html',
  styleUrls: ['./payment-reject.component.css']
})
export class PaymentRejectComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }

  // Route to the Users Dashboard
  onClick()
  {
    this.router.navigate(['listVehicle'])
  }
}
