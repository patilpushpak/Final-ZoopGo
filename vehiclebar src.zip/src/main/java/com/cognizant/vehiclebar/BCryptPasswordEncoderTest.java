package com.cognizant.vehiclebar;
// This class is used to encrypt the user password and store it in the database
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class BCryptPasswordEncoderTest {
	
	public static void main(String args[])
	{
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		System.out.println(encoder.encode("vehiclebar"));
		
	}
}
