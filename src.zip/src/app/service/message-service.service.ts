import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { AuthCredentialService } from "./auth-credential.service";

@Injectable({
  providedIn: "root"
})
export class MessageServiceService {
  OTP;
  vehicleID;

  constructor(private http: HttpClient, private auth: AuthCredentialService) {}
  //Get pending user list
  getPendingUserList() {
    return this.http.get("http://localhost:8090/pendingUser");
  }
  //Accept a pending user
  AcceptUser(u) {
    console.log(this.auth.getSessionToken());
    return this.http.post(`http://localhost:8090/userApprove`, u);
  }
  //Reject a pending user
  RejectUser(u) {
    console.log(this.auth.getSessionToken());
    return this.http.post(`http://localhost:8090/userReject`, u);
  }
  //Get a particular user information
  getUserInfo(username) {
    return this.http.get(`http://localhost:8090/userInfo/${username}`);
  }
  //Get all the permanent users
  getUserPermanent(username) {
    return this.http.get(`http://localhost:8090/user/${username}`);
  }
  //Get the notification of a particular user
  getUserNotification(username) {
    return this.http.get(`http://localhost:8090/userNotification/${username}`);
  }
  //Delete a user notification
  delUserNotification(username, msg) {
    return this.http.put(
      `http://localhost:8090/deleteNotification/${username}`,
      msg
    );
  }
  //Get the contact number of a particular user
  getContactNumber(username) {
    return this.http.get(`http://localhost:8090/userPhone/${username}`);
  }
  //Set OTP
  setOTP(otp) {
    this.OTP = otp;
  }
  //Return OTP
  getOTP() {
    return this.OTP;
  }
  //Set the Vehicle ID
  setVehicleID(id) {
    this.vehicleID = id;
  }
  //Return the Vehicle ID
  getVehicleID() {
    return this.vehicleID;
  }
}
