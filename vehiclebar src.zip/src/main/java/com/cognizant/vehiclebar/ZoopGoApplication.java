package com.cognizant.vehiclebar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZoopGoApplication {

	public static void main(String args[])
	{
		SpringApplication.run(ZoopGoApplication.class, args);
	}
}