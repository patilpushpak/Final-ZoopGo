package com.cognizant.vehiclebar.repository;
// Queries all related to user function and operation
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.vehiclebar.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
	
	// Find a user by username
	@Query(value = "SELECT * FROM user WHERE username=?;", nativeQuery = true)
	Optional<User> findUserByUsername(String username);
	
	// Find all the users who are not approved
	@Query(value = "SELECT * FROM user WHERE is_approved = 0;", nativeQuery = true)
	List<User> findPendingUsers();
	
	// Update all pending user to a status of approved
	@Modifying
	@Transactional
	@Query(value= "Update user set is_approved = 1 WHERE id = ?", nativeQuery=true)
	void approveUSer(long id);
	
	// Find user depending of contact number which is a unique entry	
	@Query(value = "SELECT * FROM user WHERE contact_number=?;", nativeQuery = true)
	Optional<User> findUserByContactNumber(String contact_number);
	
	// Query for getting the contact number of user
	@Query(value = "SELECT contact_number FROM user WHERE username=?;", nativeQuery = true)
	String getContactNumber(String userName);
}
