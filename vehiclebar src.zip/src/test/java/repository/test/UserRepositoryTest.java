package repository.test;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.cognizant.vehiclebar.ZoopGoApplication;
import com.cognizant.vehiclebar.model.User;
import com.cognizant.vehiclebar.repository.UserRepository;
import java.util.List;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = ZoopGoApplication.class)
@SpringBootTest
public class UserRepositoryTest {

	@Autowired
	UserRepository repository;
	
	@Test
	public void findUserByUsername() {
		Optional<User> user = repository.findUserByUsername("sam@zoopgo.com");
		assert(user.get().getUsername().equals("sam@zoopgo.com"));
	}
	
	@Test
	public void findPendingUsers(){
		List<User> list = repository.findPendingUsers();
		assert(!list.isEmpty());
	}
	
	@Test
	public void approveUSer(){
		repository.approveUSer(17);
		System.out.println(repository.findPendingUsers());
		assert(repository.findPendingUsers().isEmpty());
	}
	
	@Test
	public void findUserByContactNumber(){
		Optional<User> user = repository.findUserByContactNumber("9011565656");
		assert(user.get().getContactNumber().equals("9011565656"));
	}

}
