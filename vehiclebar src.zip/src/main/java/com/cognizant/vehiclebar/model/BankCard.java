package com.cognizant.vehiclebar.model;
// Model class for payment cards
public class BankCard {
	private String cardName;
	private String cardNumber;
	private String expMonth;
	private int expYear;
	private int CVV;
	public BankCard(String cardName, String cardNumber, String expMonth, int expYear, int cVV) {
		super();
		this.cardName = cardName;
		this.cardNumber = cardNumber;
		this.expMonth = expMonth;
		this.expYear = expYear;
		CVV = cVV;
	}
	public BankCard() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getExpMonth() {
		return expMonth;
	}
	public void setExpMonth(String expMonth) {
		this.expMonth = expMonth;
	}
	public int getExpYear() {
		return expYear;
	}
	public void setExpYear(int expYear) {
		this.expYear = expYear;
	}
	public int getCVV() {
		return CVV;
	}
	public void setCVV(int cVV) {
		CVV = cVV;
	}
	@Override
	public String toString() {
		return "BankCard [cardName=" + cardName + ", cardNumber=" + cardNumber + ", expMonth=" + expMonth + ", expYear="
				+ expYear + ", CVV=" + CVV + "]";
	}
	

}
