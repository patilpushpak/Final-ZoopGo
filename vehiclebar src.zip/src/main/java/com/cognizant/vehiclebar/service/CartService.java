package com.cognizant.vehiclebar.service;

// Service class for Cart controller
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.vehiclebar.model.Cart;
import com.cognizant.vehiclebar.model.Vehicle;
import com.cognizant.vehiclebar.repository.CartRepository;
import com.cognizant.vehiclebar.repository.VehicleRepository;

@Service
public class CartService {

	@Autowired
	CartRepository cartRepository;

	@Autowired
	VehicleRepository vehicleRepository;

	/*
	 * Add a cart entry
	 * Parameter: Cart Object
	 * Return: void
	 */
	public void addTocart(Cart data) {

		cartRepository.save(data);
	}

	

	/*
	 * Get all cart details based on username
	 * Parameter: String username
	 * Return: List<Vehicle>
	 */
	public List<Vehicle> getAllCartCars(String username)

	{
		return vehicleRepository.getCartByUserName(username);
	}


	/*
	 * Get all cart details based on username & password
	 * Parameter: String username, long vehicleId
	 * Return: Cart Object
	 */
	public Cart getCartInfo(String username, long vehicleId) {
		return cartRepository.getCartInfo(username, vehicleId);
	}


	/*
	 * Calculate the number of days between starting date and ending date
	 * Parameter: startDate:Date, endDate:Date
	 * Return: float
	 */
	public float CalulateDateDiff(Date startDate, Date endDate) {
		float daysBetween = 0;
		try {

			long difference = endDate.getTime() - startDate.getTime();
			daysBetween = (difference / (1000 * 60 * 60 * 24));

			System.out.println("Number of Days between dates: " + daysBetween);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return daysBetween;
	}


	/*
	 * Removes a cart entry based on vehicleID and username
	 * Parameter: Cart Object
	 * Return: void
	 */
	public void removeFromCart(String username, long vehicleId) {
		System.out.println(username + vehicleId);
		cartRepository.deleteCartItem(username, vehicleId);
	}

}
