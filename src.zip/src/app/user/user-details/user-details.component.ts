import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MessageServiceService } from 'src/app/service/message-service.service';
import { User } from '../user-reg/user-reg.component';
import { Vehicle } from 'src/app/admin/admin-edit-vehicle/admin-edit-vehicle.component';
// Display the details of a particular user
@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
 username
 u:USER
  constructor(private route:ActivatedRoute,private userService:MessageServiceService) { }

  ngOnInit() {
   this.u= new USER('','',0,'',0,'','')
    this.username = this.route.snapshot.params['username']
    this.userService.getUserInfo(this.username).subscribe(data =>{
      this.u=data
    })
  
  }

}


export class USER{



  constructor(firstName:string, lastName:string,
    age:number,
    gender:string,
  contactNumber:number,
    username:string,
    password:string){

    }

  
}
