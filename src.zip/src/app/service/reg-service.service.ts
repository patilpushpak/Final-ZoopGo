import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { AuthCredentialService } from "./auth-credential.service";

@Injectable({
  providedIn: "root"
})
export class RegServiceService {
  constructor(private http: HttpClient, private auth: AuthCredentialService) {}

  //Add a user
  addUser(user) {
    return this.http.post(`http://localhost:8090/adduser`, user);
  }

  //Add an admin
  addAdmin(user) {
    return this.http.post(`http://localhost:8090/addadmin`, user);
  }
}
