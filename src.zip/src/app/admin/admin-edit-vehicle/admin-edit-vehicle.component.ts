import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import { ListVehicleService } from "../../service/list-vehicle.service";

@Component({
  selector: "app-admin-edit-vehicle",
  templateUrl: "./admin-edit-vehicle.component.html",
  styleUrls: ["./admin-edit-vehicle.component.css"]
})
export class AdminEditVehicleComponent implements OnInit {
  id;
  vehicle;
  constructor(
    private route: ActivatedRoute,
    private listVehicle: ListVehicleService,
    private vehicleService: ListVehicleService,
    private router: Router
  ) {}

  ngOnInit() {
    this.id = this.route.snapshot.params["id"];
    this.vehicle = new Vehicle(
      0,
      0,
      "MH000",
      "Pune",
      "Sedan",
      new Date(),
      new Date(),
      new Date(),
      false,
      "xxx"
    );
    this.listVehicle.getVehicleById(this.id).subscribe(data => {
      this.vehicle = data;
    });
  }

  //Used to edit the existing vehicle details
  SubmitUpdate() {
    this.listVehicle.updateVehicle(this.vehicle, this.id).subscribe(data => {
      this.router.navigate(["adminlistVehicle"]);
    });
  }
}

export class Vehicle {
  constructor(
    id,
    name,
    vehicleNumber,
    branch,
    vehicleType,
    insuranceExpiryDate,
    lastServiceDate,
    serviceDueDate,
    active,
    image
  ) {}
}
