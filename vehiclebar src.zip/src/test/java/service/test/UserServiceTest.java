package service.test;


import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoRule;

import com.cognizant.vehiclebar.model.User;
import com.cognizant.vehiclebar.repository.UserRepository;
import com.cognizant.vehiclebar.service.UserService;


@RunWith(MockitoJUnitRunner.class)
public class UserServiceTest {
	
	@Mock
	UserRepository userRepository;
	
	@InjectMocks
	UserService userService;
	
    @Rule
    public MockitoRule rule = MockitoJUnit.rule();
	
	User user = new User();
	
	List<User> users = new ArrayList<User>();

	/*@Test	
	public void adduser() {
		User user = new User(1, "amit", "wani", 23, "Male", "9970808080", "amit@wani.com", "fjdhkdjbdh", "ADMIN", false );
		when(userRepository.save(user))
		
	}*/

}
