import { Component, OnInit } from '@angular/core';
import { AuthCredentialService } from 'src/app/service/auth-credential.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
username:string
password:string
invalid=false
invalidmsg='Sorry, you are not approved'
  constructor(private auth:AuthCredentialService,private router:Router) { }

  ngOnInit() {
  }

 // Used for authorization of admin login credentials
  handleLogin()
  {
    this.auth.handleAuthorization(this.username,this.password).subscribe(data =>
      {
        if(data.role === '[ROLE_USER]')
        {
          this.invalid=true
          this.invalidmsg='Sorry, you are a User, please go to user login'
        }
        else
        {
          this.invalid=false
          this.router.navigate(['adminlistVehicle'])
        }
      },
      error=>
      {
        if(error.error === 'INVALID_CREDENTIALS')
        {
          this.invalidmsg = "Wrong credentials"
          this.invalid = true
        }
        else
        {
          
          this.invalid=true
        }
      })
  }

}
