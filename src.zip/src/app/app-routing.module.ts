import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { UserOptionsComponent } from './user/user-options/user-options.component';
import { AdminOptionsComponent } from './admin/admin-options/admin-options.component';
import { UserLoginComponent } from './user/user-login/user-login.component';
import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { UserRegComponent } from './user/user-reg/user-reg.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { ListVehicleComponent } from './Vehicle/list-vehicle/list-vehicle.component';
import { RegSuccessComponent } from './reg-success/reg-success.component';
import { LogoutComponent } from './logout/logout.component';
import { AdminMessagesComponent } from './admin/admin-messages/admin-messages.component';
import { AdminRegComponent } from './admin/admin-reg/admin-reg.component';
import { UserDetailsComponent } from './user/user-details/user-details.component';
import { AdminListVehicleComponent } from './admin/admin-list-vehicle/admin-list-vehicle.component';
import { AdminEditVehicleComponent } from './admin/admin-edit-vehicle/admin-edit-vehicle.component';

import { UserNotificationComponent } from './user/user-notification/user-notification.component';
import { VehicleDetailsComponent } from './Vehicle/vehicle-details/vehicle-details.component';
import { AdminAddComponent } from './admin/admin-add/admin-add.component';
import { BookingPageComponent } from './booking/booking-page/booking-page.component';
import { BookedCarsComponent } from './booking/booked-cars/booked-cars.component';
import { BookingDetailsComponent } from './booking/booking-details/booking-details.component';
import { PaymentInfoComponent } from './payment/payment-info/payment-info.component';
import { PaymentCheckoutComponent } from './payment/payment-checkout/payment-checkout.component';
import { PaymentOTPComponent } from './payment/payment-otp/payment-otp.component';
import { PaymentSuccessComponent } from './payment/payment-success/payment-success.component';
import { PaymentRejectComponent } from './payment/payment-reject/payment-reject.component';


const routes: Routes = [
{path:'',component:HomeComponent},
{path:'userOption',component:UserOptionsComponent},
{path:'adminOption',component:AdminOptionsComponent},
{path:'userLogin',component:UserLoginComponent},
{path:'adminLogin',component:AdminLoginComponent},
{path:'adminReg',component:AdminRegComponent},
{path:'userReg',component:UserRegComponent},
{path:'welcome/:name',component:WelcomeComponent},
{path:'listVehicle',component:ListVehicleComponent},
{path:'regSuccess',component:RegSuccessComponent},
{path:'logout',component:LogoutComponent},
{path:'adminMsg',component:AdminMessagesComponent},
{path:'userDetails/:username',component:UserDetailsComponent},
{path:'adminlistVehicle',component:AdminListVehicleComponent},
{path:'adminEdit/:id',component:AdminEditVehicleComponent},
{path:'adminAdd',component:AdminAddComponent},
{path:'userNotification',component:UserNotificationComponent},
{path:'vehicleDetails/:id',component:VehicleDetailsComponent},
{path:'bookVehicle/:id',component:BookingPageComponent},
{path:'bookedCars',component:BookedCarsComponent},
{path:'bookingDetails/:id',component:BookingDetailsComponent},
{path:'paymentinfo/:id',component:PaymentInfoComponent},
{path:'checkout/:amount',component:PaymentCheckoutComponent},
{path:'paymentOTP',component:PaymentOTPComponent},
{path:'paymentSuccess',component:PaymentSuccessComponent},
{path:'paymentReject',component:PaymentRejectComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
